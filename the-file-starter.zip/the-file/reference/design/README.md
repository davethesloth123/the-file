# Design work

Put your own design files here — mockups, screenshots, colour studies, HUD
layouts, exports from Claude Design.

`CLAUDE.md` tells Claude Code that anything in this folder is **authoritative on
visual direction and overrides the bible where they conflict**, so keep it
current and delete anything you have moved on from.
